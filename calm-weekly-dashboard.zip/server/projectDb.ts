import { eq, and, desc } from "drizzle-orm";
import { projects, InsertProject } from "../drizzle/schema";
import { getDb } from "./db";

export async function getUserProjects(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db.select().from(projects).where(eq(projects.userId, userId));
  return result;
}

export async function createProject(userId: number, projectData: Omit<InsertProject, "userId">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const projectToInsert: InsertProject = {
    ...projectData,
    userId,
  };
  
  await db.insert(projects).values(projectToInsert);
  
  // Return the created project (get the latest one for this user)
  const created = await db
    .select()
    .from(projects)
    .where(eq(projects.userId, userId))
    .orderBy(desc(projects.createdAt))
    .limit(1);
  
  if (created.length === 0) throw new Error("Failed to create project");
  
  return created[0];
}

export async function updateProject(
  userId: number,
  projectId: number,
  updates: Partial<Omit<InsertProject, "userId" | "id">>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .update(projects)
    .set(updates)
    .where(and(eq(projects.userId, userId), eq(projects.id, projectId)));
  
  // Return updated project
  const result = await db
    .select()
    .from(projects)
    .where(and(eq(projects.userId, userId), eq(projects.id, projectId)))
    .limit(1);
  
  if (result.length === 0) throw new Error("Project not found");
  
  return result[0];
}

export async function deleteProject(userId: number, projectId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .delete(projects)
    .where(and(eq(projects.userId, userId), eq(projects.id, projectId)));
  
  return { success: true };
}
