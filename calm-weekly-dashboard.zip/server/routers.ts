import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as taskDb from "./taskDb";
import * as projectDb from "./projectDb";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  tasks: router({
    // Get all tasks for the current user
    getAll: protectedProcedure.query(async ({ ctx }) => {
      return await taskDb.getUserTasks(ctx.user.id);
    }),

    // Get backlog tasks (not assigned to any week)
    getBacklog: protectedProcedure.query(async ({ ctx }) => {
      return await taskDb.getBacklogTasks(ctx.user.id);
    }),

    // Get tasks for a specific week
    getWeek: protectedProcedure
      .input(z.object({ weekKey: z.string() }))
      .query(async ({ ctx, input }) => {
        return await taskDb.getWeekTasks(ctx.user.id, input.weekKey);
      }),

    // Create a new task
    create: protectedProcedure
      .input(
        z.object({
          taskId: z.string(),
          text: z.string(),
          completed: z.boolean().optional(),
          status: z.enum(["not-started", "in-progress", "blocked", "in-review", "done"]).optional(),
          notes: z.string().optional(),
          links: z.array(z.object({ title: z.string(), url: z.string() })).optional(),
          attachments: z.array(z.object({ name: z.string(), url: z.string() })).optional(),
          weekKey: z.string().optional(),
          dayIndex: z.number().optional(),
          timeSlotIndex: z.number().optional(),
          position: z.number().optional(),
          dueDate: z.date().optional(),
          urgent: z.boolean().optional(),
          important: z.boolean().optional(),
          estimatedDuration: z.number().optional(),
          startTime: z.number().optional(),
          projectId: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Convert boolean completed to number for database
        const dbInput: any = { ...input };
        if (input.completed !== undefined) {
          dbInput.completed = input.completed ? 1 : 0;
        }
        return await taskDb.createTask(ctx.user.id, dbInput);
      }),

    // Update a task
    update: protectedProcedure
      .input(
        z.object({
          taskId: z.string(),
          text: z.string().optional(),
          completed: z.boolean().optional(),
          status: z.enum(["not-started", "in-progress", "blocked", "in-review", "done"]).optional(),
          notes: z.string().optional(),
          links: z.array(z.object({ title: z.string(), url: z.string() })).optional(),
          attachments: z.array(z.object({ name: z.string(), url: z.string() })).optional(),
          weekKey: z.string().optional().nullable(),
          dayIndex: z.number().optional().nullable(),
          timeSlotIndex: z.number().optional().nullable(),
          position: z.number().optional(),
          dueDate: z.date().optional().nullable(),
          urgent: z.boolean().optional(),
          important: z.boolean().optional(),
          estimatedDuration: z.number().optional().nullable(),
          startTime: z.number().optional().nullable(),
          projectId: z.number().optional().nullable(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { taskId, ...updates } = input;
        // Convert boolean completed to number for database
        const dbUpdates: any = { ...updates };
        if (updates.completed !== undefined) {
          dbUpdates.completed = updates.completed ? 1 : 0;
        }
        return await taskDb.updateTask(ctx.user.id, taskId, dbUpdates);
      }),

    // Delete a task
    delete: protectedProcedure
      .input(z.object({ taskId: z.string() }))
      .mutation(async ({ ctx, input }) => {
        return await taskDb.deleteTask(ctx.user.id, input.taskId);
      }),

    // Bulk update tasks (for drag-and-drop operations)
    bulkUpdate: protectedProcedure
      .input(
        z.object({
          updates: z.array(
            z.object({
              taskId: z.string(),
              updates: z.object({
                weekKey: z.string().optional().nullable(),
                dayIndex: z.number().optional().nullable(),
                timeSlotIndex: z.number().optional().nullable(),
                position: z.number().optional(),
                status: z.enum(["not-started", "in-progress", "blocked", "in-review", "done"]).optional(),
              }),
            })
          ),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await taskDb.bulkUpdateTasks(ctx.user.id, input.updates);
      }),

    // Move all incomplete tasks from a specific week to backlog
    moveIncompleteToBacklog: protectedProcedure
      .input(z.object({ weekKey: z.string() }))
      .mutation(async ({ ctx, input }) => {
        // Get all incomplete tasks for the specified week
        const weekTasks = await taskDb.getWeekTasks(ctx.user.id, input.weekKey);
        const incompleteTasks = weekTasks.filter(task => !task.completed);
        
        // Move them to backlog by clearing weekKey, dayIndex, and timeSlotIndex
        const updates = incompleteTasks.map(task => ({
          taskId: task.taskId,
          updates: {
            weekKey: null,
            dayIndex: null,
            timeSlotIndex: null,
          },
        }));
        
        await taskDb.bulkUpdateTasks(ctx.user.id, updates);
        
        return { movedCount: incompleteTasks.length };
      }),
  }),

  projects: router({
    // Get all projects for the current user
    getAll: protectedProcedure.query(async ({ ctx }) => {
      return await projectDb.getUserProjects(ctx.user.id);
    }),

    // Create a new project
    create: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          description: z.string().optional(),
          color: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await projectDb.createProject(ctx.user.id, input);
      }),

    // Update a project
    update: protectedProcedure
      .input(
        z.object({
          projectId: z.number(),
          name: z.string().optional(),
          description: z.string().optional(),
          color: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { projectId, ...updates } = input;
        return await projectDb.updateProject(ctx.user.id, projectId, updates);
      }),

    // Delete a project
    delete: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return await projectDb.deleteProject(ctx.user.id, input.projectId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
