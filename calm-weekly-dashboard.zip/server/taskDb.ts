import { eq, and, isNull } from "drizzle-orm";
import { tasks, InsertTask } from "../drizzle/schema";
import { getDb } from "./db";

export async function getUserTasks(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db.select().from(tasks).where(eq(tasks.userId, userId));
  
  // Parse JSON fields
  return result.map((task) => ({
    ...task,
    links: task.links ? JSON.parse(task.links) : [],
    attachments: task.attachments ? JSON.parse(task.attachments) : [],
    completed: task.completed === 1,
    urgent: task.urgent === 1,
    important: task.important === 1,
  }));
}

export async function getBacklogTasks(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db
    .select()
    .from(tasks)
    .where(and(eq(tasks.userId, userId), isNull(tasks.weekKey)));
  
  return result.map((task) => ({
    ...task,
    links: task.links ? JSON.parse(task.links) : [],
    attachments: task.attachments ? JSON.parse(task.attachments) : [],
    completed: task.completed === 1,
    urgent: task.urgent === 1,
    important: task.important === 1,
  }));
}

export async function getWeekTasks(userId: number, weekKey: string) {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db
    .select()
    .from(tasks)
    .where(and(eq(tasks.userId, userId), eq(tasks.weekKey, weekKey)));
  
  return result.map((task) => ({
    ...task,
    links: task.links ? JSON.parse(task.links) : [],
    attachments: task.attachments ? JSON.parse(task.attachments) : [],
    completed: task.completed === 1,
    urgent: task.urgent === 1,
    important: task.important === 1,
  }));
}

export async function createTask(userId: number, taskData: Omit<InsertTask, "userId">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const taskToInsert: InsertTask = {
    ...taskData,
    userId,
    links: taskData.links ? JSON.stringify(taskData.links) : null,
    attachments: taskData.attachments ? JSON.stringify(taskData.attachments) : null,
    completed: taskData.completed ? 1 : 0,
    urgent: taskData.urgent ? 1 : 0,
    important: taskData.important ? 1 : 0,
  };
  
  await db.insert(tasks).values(taskToInsert);
  
  // Return the created task
  const result = await db
    .select()
    .from(tasks)
    .where(eq(tasks.taskId, taskData.taskId!))
    .limit(1);
  
  if (result.length === 0) throw new Error("Failed to create task");
  
  return {
    ...result[0],
    links: result[0].links ? JSON.parse(result[0].links) : [],
    attachments: result[0].attachments ? JSON.parse(result[0].attachments) : [],
    completed: result[0].completed === 1,
    urgent: result[0].urgent === 1,
    important: result[0].important === 1,
  };
}

export async function updateTask(
  userId: number,
  taskId: string,
  updates: Partial<Omit<InsertTask, "userId" | "taskId">>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const updateData: any = { ...updates };
  if (updates.links) updateData.links = JSON.stringify(updates.links);
  if (updates.attachments) updateData.attachments = JSON.stringify(updates.attachments);
  if (updates.completed !== undefined) updateData.completed = updates.completed ? 1 : 0;
  if (updates.urgent !== undefined) updateData.urgent = updates.urgent ? 1 : 0;
  if (updates.important !== undefined) updateData.important = updates.important ? 1 : 0;
  
  await db
    .update(tasks)
    .set(updateData)
    .where(and(eq(tasks.userId, userId), eq(tasks.taskId, taskId)));
  
  // Return updated task
  const result = await db
    .select()
    .from(tasks)
    .where(and(eq(tasks.userId, userId), eq(tasks.taskId, taskId)))
    .limit(1);
  
  if (result.length === 0) throw new Error("Task not found");
  
  return {
    ...result[0],
    links: result[0].links ? JSON.parse(result[0].links) : [],
    attachments: result[0].attachments ? JSON.parse(result[0].attachments) : [],
    completed: result[0].completed === 1,
    urgent: result[0].urgent === 1,
    important: result[0].important === 1,
  };
}

export async function deleteTask(userId: number, taskId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .delete(tasks)
    .where(and(eq(tasks.userId, userId), eq(tasks.taskId, taskId)));
  
  return { success: true };
}

export async function bulkUpdateTasks(
  userId: number,
  updates: Array<{ taskId: string; updates: Partial<Omit<InsertTask, "userId" | "taskId">> }>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Execute all updates
  for (const { taskId, updates: taskUpdates } of updates) {
    const updateData: any = { ...taskUpdates };
    if (taskUpdates.links) updateData.links = JSON.stringify(taskUpdates.links);
    if (taskUpdates.attachments) updateData.attachments = JSON.stringify(taskUpdates.attachments);
    if (taskUpdates.completed !== undefined) updateData.completed = taskUpdates.completed ? 1 : 0;
    if (taskUpdates.urgent !== undefined) updateData.urgent = taskUpdates.urgent ? 1 : 0;
    if (taskUpdates.important !== undefined) updateData.important = taskUpdates.important ? 1 : 0;
    
    await db
      .update(tasks)
      .set(updateData)
      .where(and(eq(tasks.userId, userId), eq(tasks.taskId, taskId)));
  }
  
  return { success: true };
}
