import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Subscription tiers for monetization
 */
export const subscriptionTiers = mysqlEnum("subscriptionTier", ["free", "ad-free", "pro"]);

/**
 * User subscriptions table
 */
export const userSubscriptions = mysqlTable("userSubscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  tier: subscriptionTiers.notNull().default("free"),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
  currentPeriodEnd: timestamp("currentPeriodEnd"),
  cancelAtPeriodEnd: int("cancelAtPeriodEnd").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserSubscription = typeof userSubscriptions.$inferSelect;
export type InsertUserSubscription = typeof userSubscriptions.$inferInsert;

/**
 * Tasks table - stores individual tasks with details
 */
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  taskId: varchar("taskId", { length: 64 }).notNull().unique(), // Client-generated ID for consistency
  text: text("text").notNull(),
  completed: int("completed").default(0).notNull(),
  status: mysqlEnum("status", ["not-started", "in-progress", "blocked", "in-review", "done"]).default("not-started").notNull(),
  notes: text("notes"),
  links: text("links"), // JSON array of {title, url}
  attachments: text("attachments"), // JSON array of {name, url}
  weekKey: varchar("weekKey", { length: 32 }), // Format: YYYY-WNN (e.g., 2026-W06)
  dayIndex: int("dayIndex"), // 0-4 for Mon-Fri, null for backlog
  timeSlotIndex: int("timeSlotIndex"), // DEPRECATED: will be removed, use startTime instead
  position: int("position").default(0), // For ordering within a slot
  // New fields for advanced task management
  dueDate: timestamp("dueDate"), // When the task is due
  urgent: int("urgent").default(0), // Boolean: 1 = urgent, 0 = not urgent
  important: int("important").default(0), // Boolean: 1 = important, 0 = not important
  estimatedDuration: int("estimatedDuration"), // Duration in minutes
  startTime: int("startTime"), // Start time in minutes from midnight (e.g., 300 = 5am, 540 = 9am, 780 = 1pm)
  projectId: int("projectId"), // Foreign key to projects table
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

/**
 * Projects table - for grouping related tasks
 */
export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  color: varchar("color", { length: 7 }), // Hex color code (e.g., #FF5733)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;