/* Scandinavian Hygge with Soft Modernism - Fresh Rebuild with Database Integration */

import { useState, useEffect, useMemo } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { useTaskData } from "@/hooks/useTaskData";
import { useLocalStorageMigration } from "@/hooks/useLocalStorageMigration";
import {
  DndContext,
  DragEndEvent,
  DragOverlay,
  DragStartEvent,
  DragOverEvent,
  PointerSensor,
  useSensor,
  useSensors,
  pointerWithin,
  closestCenter,
} from "@dnd-kit/core";
import { arrayMove } from "@dnd-kit/sortable";
import { Loader2, ChevronLeft, ChevronRight, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BacklogColumn } from "@/components/BacklogColumn";
import { WeeklyView } from "@/components/WeeklyView";
import KanbanView from "@/components/KanbanView";
import TaskDetailModal, { TaskDetails, TaskStatus } from "@/components/TaskDetailModal";

import { getWeekKey, getCurrentWeekMonday, formatWeekRange } from "@/utils/dateUtils";

export default function Home() {
  // Authentication check
  const { user, loading: authLoading, isAuthenticated, logout } = useAuth();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      window.location.href = getLoginUrl();
    }
  }, [authLoading, isAuthenticated]);

  // Week navigation
  const [currentWeekStart, setCurrentWeekStart] = useState(() => getCurrentWeekMonday());
  const currentWeekKey = getWeekKey(currentWeekStart);

  // Migrate localStorage data on first login
  const { isMigrating, migrationComplete } = useLocalStorageMigration();

  // Load tasks from database
  const taskData = useTaskData(currentWeekStart);

  // UI state
  const [view, setView] = useState<"weekly" | "kanban">("weekly");
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [dragPosition, setDragPosition] = useState<{ x: number; y: number } | null>(null);
  const [activeDayIndex, setActiveDayIndex] = useState<number | null>(null);

  // Drag-and-drop sensors
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  // Week navigation handlers
  const goToPreviousWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() - 7);
    setCurrentWeekStart(newDate);
  };

  const goToNextWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() + 7);
    setCurrentWeekStart(newDate);
  };

  const goToCurrentWeek = () => {
    setCurrentWeekStart(getCurrentWeekMonday());
  };

  // Task handlers
  const handleToggleTask = async (taskId: string) => {
    await taskData.toggleTask(taskId);
  };

  const handleEditTask = (taskId: string, text: string) => {
    setEditingTaskId(taskId);
    setEditText(text);
  };

  const handleEditSave = async () => {
    if (editingTaskId && editText.trim()) {
      await taskData.editTaskText(editingTaskId, editText);
      setEditingTaskId(null);
      setEditText("");
    }
  };

  const handleEditCancel = () => {
    setEditingTaskId(null);
    setEditText("");
  };

  const handleAddTask = async (location: string, text: string) => {
    await taskData.addTask(text, location, currentWeekKey);
  };

  const handleDeleteTask = async (taskId: string) => {
    await taskData.removeTask(taskId);
    setDetailModalOpen(false);
  };

  const handleOpenDetails = (taskId: string) => {
    setSelectedTaskId(taskId);
    setDetailModalOpen(true);
  };

  const handleSaveDetails = async (details: TaskDetails) => {
    if (selectedTaskId) {
      await taskData.updateTaskDetails(selectedTaskId, details);
    }
  };

  // Get selected task for detail modal
  const getSelectedTask = () => {
    const allTasks = [...taskData.backlogTasks, ...taskData.allTasksFromAllWeeks];
    return allTasks.find((task) => task.id === selectedTaskId);
  };

  // Drag-and-drop handlers
  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string);
    setActiveDayIndex(null);
  };

  const [dropCoordinates, setDropCoordinates] = useState<{ x: number; y: number } | null>(null);

  const handleDragOver = (event: DragOverEvent) => {
    // Capture the current drag position
    if (event.delta) {
      setDragPosition({ x: event.delta.x, y: event.delta.y });
    }
    // Capture actual pointer coordinates for drop calculation
    if (event.activatorEvent && 'clientX' in event.activatorEvent) {
      const pointerEvent = event.activatorEvent as PointerEvent;
      setDropCoordinates({ x: pointerEvent.clientX, y: pointerEvent.clientY });
    }
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over, activatorEvent, delta } = event;
    setActiveId(null);
    setDragPosition(null);
    setActiveDayIndex(null);

    if (!over) return;

    const activeId = String(active.id);
    const overId = String(over.id);

    // Find the source task
    const allTasks = [...taskData.backlogTasks, ...taskData.allTasksFromAllWeeks];
    const sourceTask = allTasks.find((t) => t.id === activeId);
    if (!sourceTask) return;

    // Determine destination
    let toLocation: string;
    
    if (overId === "backlog") {
      // Dropped on backlog
      toLocation = "backlog";
    } else if (/^\d+-\d+$/.test(overId)) {
      // Dropped on a time slot zone (format: "dayIndex-timeSlotIndex")
      toLocation = overId;
    } else {
      // Dropped on another task - find that task's location
      const targetTask = allTasks.find((t) => t.id === overId);
      if (!targetTask) return;
      
      // Find the target task's location
      const targetDbTask = taskData.days.flatMap((day, dayIdx) =>
        day.timeSlots.flatMap((slot, slotIdx) =>
          slot.tasks.map((task) => ({ task, dayIdx, slotIdx }))
        )
      ).find((item) => item.task.id === overId);
      
      if (targetDbTask) {
        toLocation = `${targetDbTask.dayIdx}-${targetDbTask.slotIdx}`;
      } else if (!targetTask.weekKey) {
        toLocation = "backlog";
      } else {
        return;
      }
    }

    // Calculate startTime if dropping in a time slot
    let startTime: number | undefined;
    if (/^\d+-\d+$/.test(toLocation) && over.rect && active.rect.current.translated) {
      // FIXED: Get actual DOM element position instead of using stale over.rect
      const TIMELINE_HEIGHT = 3800; // 100px per 30min * 38 blocks (19 hours)
      
      // Find the actual droppable DOM element
      const droppableElement = document.querySelector(`[data-droppable-id="${over.id}"]`);
      
      if (droppableElement) {
        const containerRect = droppableElement.getBoundingClientRect();
        const draggedElementBottom = active.rect.current.translated.bottom;
        const draggedElementTop = active.rect.current.translated.top;
        const draggedElementCenter = (draggedElementTop + draggedElementBottom) / 2;
        
        // Use actual container top from DOM
        const actualZoneTop = containerRect.top;
        const yOffset = Math.max(0, draggedElementCenter - actualZoneTop);
        
        console.log('[DROP DEBUG]', {
          draggedElementCenter,
          actualZoneTop,
          yOffset,
          containerHeight: containerRect.height,
          TIMELINE_HEIGHT
        });
        
        // Single continuous time slot: 5am-12am = 1140 minutes (19 hours)
        const slotDuration = 1140;
        
        // Calculate time based on Y position within the full day timeline
        const timeInSlot = Math.max(0, Math.min(slotDuration, (yOffset / TIMELINE_HEIGHT) * slotDuration));
        
        // Snap to nearest 30 minutes
        startTime = Math.round(timeInSlot / 30) * 30;
        
        console.log('[TIME CALC]', { yOffset, timeInSlot, startTime });
      }
    }
    
    // Clear drop coordinates
    setDropCoordinates(null);

    // Move task in database with optional startTime
    await taskData.moveTask(activeId, toLocation, currentWeekKey, startTime);
  };

  // Loading state
  if (authLoading || taskData.isLoading || isMigrating) {
    return (
      <div className="min-h-screen grain-texture flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading your calm week...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (taskData.error) {
    return (
      <div className="min-h-screen grain-texture flex items-center justify-center">
        <div className="flex flex-col items-center gap-4 text-center">
          <p className="text-destructive">Failed to load tasks</p>
          <Button onClick={() => window.location.reload()}>Retry</Button>
        </div>
      </div>
    );
  }

  // Calculate weekly progress
  const currentWeekTasks = taskData.days.flatMap((day) =>
    day.timeSlots.flatMap((slot) => slot.tasks)
  );
  const completedCount = currentWeekTasks.filter((t) => t.completed).length;
  const totalCount = currentWeekTasks.length;
  const percentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={handleDragStart}
      onDragOver={handleDragOver}
      onDragEnd={handleDragEnd}
    >
      <div className="min-h-screen grain-texture relative">
        {/* Hero Section */}
        <div
          className="relative h-48 flex items-center justify-center overflow-hidden"
          style={{
            backgroundImage:
              "url('https://private-us-east-1.manuscdn.com/sessionFile/0XYNCtEJyugFfKTZSfynDY/sandbox/Jko6fpwHPdMvaURKCNoq2U-img-1_1770757943000_na1fn_aGVyby1iYWNrZ3JvdW5k.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvMFhZTkN0RUp5dWdGZktUWlNmeW5EWS9zYW5kYm94L0prbzZmcHdIUGRNdmFVUktDTm9xMlUtaW1nLTFfMTc3MDc1Nzk0MzAwMF9uYTFmbl9hR1Z5YnkxaVlXTnJaM0p2ZFc1ay5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=DTunLx5g0cUVPjhwpdTAcJeCT5A2BxqJ1q64YSjByl5Xs05rC51JFCWXNylA-hpkyuq~v~HMhKtcG9nZKmSzMGORW~5fPB~gOGCRp4hZ8yat6G~~oRi~aJ~iz-uy84nqOLJSNdJ8bqgdlfjfMeLj6tzTliKo7o9bg6S6P~8o3U0Df~k9q~4lXDe4myuVcKe8KD~ZXXuSgBEW1c9-Lc47Gb6jIgpTx4y35aGJaqWT2bjdglpXVKsuRUru84p7GlFbQbMuQdYsC-i8woFQy-9HXhVTs4-Lgqe21taxywhVn532x2ku7XbbVo4llH2CVJ-lw8M1-jht9Eg3tURDef-Q~A__')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            height: "119px",
          }}
        >
          <div className="relative z-10 text-center px-6">
            <div className="absolute top-4 right-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  logout();
                  window.location.href = getLoginUrl();
                }}
              >
                Logout
              </Button>
            </div>
            <h1
              className="text-4xl font-semibold text-charcoal mb-2"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Your Calm Week
            </h1>
            <p className="text-base text-charcoal/70" style={{ fontFamily: "var(--font-body)" }}>
              A peaceful space to organize your work and find balance
            </p>
            {user && (
              <p className="text-xs text-charcoal/50 mt-1">
                Logged in as: {user.name || user.openId}
              </p>
            )}
          </div>
        </div>

        {/* Controls */}
        <div className="container py-6">
          <div className="flex items-center justify-between mb-6">
            {/* Week Navigation - Only show in weekly view */}
            {view === "weekly" && (
              <div className="flex flex-col gap-3">
                <div className="flex items-center gap-4">
                  <Button variant="outline" size="sm" onClick={goToPreviousWeek}>
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <span className="text-lg font-medium" style={{ fontFamily: "var(--font-display)" }}>
                    Week of {currentWeekStart.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
                  </span>
                  <Button variant="outline" size="sm" onClick={goToNextWeek}>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={goToCurrentWeek}>
                    <Calendar className="w-4 h-4 mr-2" />
                    This Week
                  </Button>
                </div>
                {/* Weekly Progress Indicator */}
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary transition-all duration-500 ease-out"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                  <span className="text-sm text-muted-foreground min-w-[80px]">
                    {completedCount} / {totalCount} ({percentage}%)
                  </span>
                </div>
              </div>
            )}

            {/* Kanban view - show title instead of navigation */}
            {view === "kanban" && (
              <h2 className="text-2xl font-semibold text-charcoal" style={{ fontFamily: "var(--font-display)" }}>
                All Tasks
              </h2>
            )}

            {/* View Toggle */}
            <Tabs value={view} onValueChange={(v) => setView(v as "weekly" | "kanban")}>
              <TabsList>
                <TabsTrigger value="weekly">Weekly Plan</TabsTrigger>
                <TabsTrigger value="kanban">Kanban</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Main Content */}
          {view === "weekly" ? (
            <div className="flex gap-6">
              {/* Backlog Column */}
              <BacklogColumn
                tasks={taskData.backlogTasks}
                onToggleTask={handleToggleTask}
                onEditTask={handleEditTask}
                onOpenDetails={handleOpenDetails}
                onAddTask={(text) => handleAddTask("backlog", text)}
                editingTaskId={editingTaskId}
                editText={editText}
                onEditChange={setEditText}
                onEditSave={handleEditSave}
                onEditCancel={handleEditCancel}
              />

              {/* Weekly Grid */}
              <WeeklyView
                days={taskData.days}
                onToggleTask={handleToggleTask}
                onEditTask={handleEditTask}
                onOpenDetails={handleOpenDetails}
                onAddTask={handleAddTask}
                editingTaskId={editingTaskId}
                editText={editText}
                onEditChange={setEditText}
                onEditSave={handleEditSave}
                onEditCancel={handleEditCancel}
              />
            </div>
          ) : (
            <KanbanView
              tasks={taskData.allTasksFromAllWeeks}
              backlogTasks={taskData.backlogTasks}
              onToggleTask={handleToggleTask}
              onEditTask={handleEditTask}
              onDeleteTask={handleDeleteTask}
              onOpenDetails={handleOpenDetails}
              editingTaskId={editingTaskId}
              editText={editText}
              onEditChange={setEditText}
              onEditSave={handleEditSave}
              onEditCancel={handleEditCancel}
            />
          )}
        </div>

        {/* Task Detail Modal */}
        {selectedTaskId && getSelectedTask() && (
          <TaskDetailModal
            isOpen={detailModalOpen}
            onClose={() => setDetailModalOpen(false)}
            taskTitle={getSelectedTask()!.text}
            details={getSelectedTask()!.details}
            onSave={handleSaveDetails}
            onDelete={() => handleDeleteTask(selectedTaskId)}
          />
        )}

        <DragOverlay>
          {activeId ? (
            <div className="bg-card p-4 rounded-[24px] shadow-lg border">
              {[...taskData.backlogTasks, ...taskData.allTasksFromAllWeeks].find((t) => t.id === activeId)?.text}
            </div>
          ) : null}
        </DragOverlay>
      </div>
    </DndContext>
  );
}
