import { useState } from "react";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { ChevronDown, ChevronUp, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { TaskCard } from "@/components/TaskCard";
import { DroppableZone } from "@/components/DroppableZone";
import { TaskDetails } from "@/components/TaskDetailModal";

interface Task {
  id: string;
  text: string;
  completed: boolean;
  details: TaskDetails;
  weekKey?: string;
}

interface TimeSlotProps {
  time: string;
  tasks: Task[];
  dropZoneId: string;
  onToggleTask: (taskId: string) => void;
  onEditTask: (taskId: string, text: string) => void;
  onOpenDetails: (taskId: string) => void;
  onAddTask: (text: string) => void;
  editingTaskId: string | null;
  editText: string;
  onEditChange: (text: string) => void;
  onEditSave: () => void;
  onEditCancel: () => void;
}

export function TimeSlot({
  time,
  tasks,
  dropZoneId,
  onToggleTask,
  onEditTask,
  onOpenDetails,
  onAddTask,
  editingTaskId,
  editText,
  onEditChange,
  onEditSave,
  onEditCancel,
}: TimeSlotProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [newTaskText, setNewTaskText] = useState("");

  const handleAddTask = () => {
    if (newTaskText.trim()) {
      onAddTask(newTaskText);
      setNewTaskText("");
      setIsAdding(false);
    }
  };

  return (
    <Collapsible open={isOpen}>
      <div className="space-y-2">
        <CollapsibleTrigger
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center justify-between w-full text-left group"
        >
          <h3
            className="text-sm font-medium text-muted-foreground uppercase tracking-wide"
            style={{ fontFamily: "var(--font-body)" }}
          >
            {time}
          </h3>
          {isOpen ? (
            <ChevronUp className="w-4 h-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="w-4 h-4 text-muted-foreground" />
          )}
        </CollapsibleTrigger>

        <CollapsibleContent>
          <DroppableZone id={dropZoneId}>
            <SortableContext
              items={tasks.map((t) => t.id)}
              strategy={verticalListSortingStrategy}
            >
              <div className="space-y-2 min-h-[60px]">
                {tasks.map((task) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    onToggle={() => onToggleTask(task.id)}
                    onEdit={() => onEditTask(task.id, task.text)}
                    onOpenDetails={() => onOpenDetails(task.id)}
                    isEditing={editingTaskId === task.id}
                    editText={editText}
                    onEditChange={onEditChange}
                    onEditSave={onEditSave}
                    onEditCancel={onEditCancel}
                  />
                ))}

                {isAdding ? (
                  <div className="flex gap-2">
                    <Input
                      value={newTaskText}
                      onChange={(e) => setNewTaskText(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleAddTask();
                        if (e.key === "Escape") setIsAdding(false);
                      }}
                      placeholder="Task title..."
                      autoFocus
                      className="flex-1"
                    />
                    <Button size="sm" onClick={handleAddTask}>
                      Add
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsAdding(true)}
                    className="w-full border-dashed"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Task
                  </Button>
                )}
              </div>
            </SortableContext>
          </DroppableZone>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}
