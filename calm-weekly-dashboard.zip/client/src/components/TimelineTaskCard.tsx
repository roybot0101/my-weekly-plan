import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Check, GripVertical } from "lucide-react";
import { TaskStatus } from "@/components/TaskDetailModal";
import { Input } from "@/components/ui/input";
import { Task } from "@/types/task";

interface TimelineTaskCardProps {
  task: Task;
  onToggle: () => void;
  onEdit: () => void;
  onOpenDetails: () => void;
  isEditing: boolean;
  editText: string;
  onEditChange: (text: string) => void;
  onEditSave: () => void;
  onEditCancel: () => void;
  style?: React.CSSProperties;
}

function getStatusColor(status: TaskStatus): string {
  switch (status) {
    case "not-started":
      return "bg-card";
    case "in-progress":
      return "bg-green-50 border-green-200";
    case "blocked":
      return "bg-red-50 border-red-200";
    case "in-review":
      return "bg-blue-50 border-blue-200";
    case "done":
      return "bg-accent/20 opacity-60";
    default:
      return "bg-card";
  }
}

export function TimelineTaskCard({
  task,
  onToggle,
  onEdit,
  onOpenDetails,
  isEditing,
  editText,
  onEditChange,
  onEditSave,
  onEditCancel,
  style,
}: TimelineTaskCardProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: task.id,
  });

  const dragStyle = {
    ...style,
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    position: 'absolute' as const,
    left: '8px',
    right: '8px',
    zIndex: isDragging ? 50 : 10,
  };

  return (
    <div
      ref={setNodeRef}
      style={dragStyle}
      // Apply cursor-pointer to the entire card
      className={`
        rounded-lg
        flex items-start gap-2 px-3 py-2
        transition-all duration-300
        ${getStatusColor(task.details.status)}
        shadow-sm border border-border/50
        group hover:shadow-lg
        cursor-pointer
      `}
      onClick={(e) => {
        // Only open details if clicking the card background
        if (e.target === e.currentTarget) {
          onOpenDetails();
        }
      }}
    >
      {/* Checkbox */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          onToggle();
        }}
        className={`
          mt-0.5 w-4 h-4 rounded-full border-2 flex-shrink-0
          flex items-center justify-center
          transition-all duration-400
          cursor-pointer
          ${
            task.completed
              ? "bg-primary border-primary"
              : "border-muted-foreground/40 hover:border-primary/60 hover:scale-110"
          }
        `}
      >
        {task.completed && <Check className="w-3 h-3 text-primary-foreground" />}
      </button>

      {/* Task content */}
      <div className="flex-1 min-w-0">
        {isEditing ? (
          <Input
            type="text"
            value={editText}
            onChange={(e) => onEditChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") onEditSave();
              if (e.key === "Escape") onEditCancel();
              e.stopPropagation();
            }}
            onBlur={onEditSave}
            onClick={(e) => e.stopPropagation()}
            className="h-6 px-2 py-1 text-sm"
            autoFocus
          />
        ) : (
          <>
            {/* Title - text cursor for editing */}
            <div
              onClick={(e) => {
                e.stopPropagation();
                onEdit();
              }}
              className="cursor-text hover:bg-accent/10 rounded px-1 -mx-1 mb-1"
            >
              <p
                className={`
                  text-sm leading-tight
                  ${task.completed ? "line-through text-muted-foreground" : "text-card-foreground"}
                `}
              >
                {task.text}
              </p>
              {task.estimatedDuration && (
                <p className="text-xs text-muted-foreground mt-0.5">
                  {formatDuration(task.estimatedDuration)}
                </p>
              )}
            </div>
            
            {/* Metadata indicators */}
            {(task.details.notes ||
              task.details.links.length > 0 ||
              task.details.attachments.length > 0) && (
              <div className="flex gap-1">
                {task.details.notes && <span className="text-xs text-muted-foreground">📝</span>}
                {task.details.links.length > 0 && (
                  <span className="text-xs text-muted-foreground">
                    🔗 {task.details.links.length}
                  </span>
                )}
                {task.details.attachments.length > 0 && (
                  <span className="text-xs text-muted-foreground">
                    📎 {task.details.attachments.length}
                  </span>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* Drag handle - always visible */}
      <div
        {...attributes}
        {...listeners}
        className="flex-shrink-0 cursor-grab active:cursor-grabbing transition-opacity"
        onClick={(e) => e.stopPropagation()}
      >
        <GripVertical className="w-4 h-4 text-muted-foreground" />
      </div>
    </div>
  );
}

function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes}min`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins === 0 ? `${hours}h` : `${hours}h ${mins}m`;
}
