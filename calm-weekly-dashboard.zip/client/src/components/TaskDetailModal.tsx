/* Task Detail Modal Component
   Rich text editor with links, attachments, and status support */

import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Link as LinkIcon, Paperclip, Plus } from "lucide-react";

interface TaskLink {
  id: string;
  url: string;
  title: string;
}

interface TaskAttachment {
  id: string;
  name: string;
  url: string;
}

export type TaskStatus = "not-started" | "in-progress" | "blocked" | "in-review" | "done";

export interface TaskDetails {
  notes: string;
  links: TaskLink[];
  attachments: TaskAttachment[];
  status: TaskStatus;
  estimatedDuration?: number; // in minutes
  dueDate?: string;
  urgent?: boolean;
  important?: boolean;
  projectId?: string;
}

interface TaskDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  taskTitle: string;
  details: TaskDetails;
  onSave: (details: TaskDetails) => void;
  onDelete?: () => void;
}

export default function TaskDetailModal({
  isOpen,
  onClose,
  taskTitle,
  details,
  onSave,
  onDelete,
}: TaskDetailModalProps) {
  const [notes, setNotes] = useState(details.notes);
  const [links, setLinks] = useState<TaskLink[]>(details.links);
  const [attachments, setAttachments] = useState<TaskAttachment[]>(details.attachments);
  const [status, setStatus] = useState<TaskStatus>(details.status);
  const [estimatedDuration, setEstimatedDuration] = useState<number>(details.estimatedDuration || 60);
  const [dueDate, setDueDate] = useState<string>(details.dueDate || "");
  const [urgent, setUrgent] = useState<boolean>(details.urgent || false);
  const [important, setImportant] = useState<boolean>(details.important || false);
  const [newLinkUrl, setNewLinkUrl] = useState("");
  const [newLinkTitle, setNewLinkTitle] = useState("");
  const [showLinkForm, setShowLinkForm] = useState(false);
  const [newAttachmentName, setNewAttachmentName] = useState("");
  const [newAttachmentUrl, setNewAttachmentUrl] = useState("");
  const [showAttachmentForm, setShowAttachmentForm] = useState(false);

  useEffect(() => {
    setNotes(details.notes);
    setLinks(details.links);
    setAttachments(details.attachments);
    setStatus(details.status);
    setEstimatedDuration(details.estimatedDuration || 60);
    setDueDate(details.dueDate || "");
    setUrgent(details.urgent || false);
    setImportant(details.important || false);
  }, [details]);

  const handleSave = () => {
    onSave({ 
      notes, 
      links, 
      attachments, 
      status, 
      estimatedDuration,
      dueDate: dueDate || undefined,
      urgent,
      important
    });
    onClose();
  };

  const addLink = () => {
    if (newLinkUrl.trim()) {
      setLinks([
        ...links,
        {
          id: Date.now().toString(),
          url: newLinkUrl,
          title: newLinkTitle || newLinkUrl,
        },
      ]);
      setNewLinkUrl("");
      setNewLinkTitle("");
      setShowLinkForm(false);
    }
  };

  const removeLink = (id: string) => {
    setLinks(links.filter((link) => link.id !== id));
  };

  const addAttachment = () => {
    if (newAttachmentUrl.trim()) {
      setAttachments([
        ...attachments,
        {
          id: Date.now().toString(),
          name: newAttachmentName || "Attachment",
          url: newAttachmentUrl,
        },
      ]);
      setNewAttachmentName("");
      setNewAttachmentUrl("");
      setShowAttachmentForm(false);
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments(attachments.filter((att) => att.id !== id));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl" style={{ fontFamily: "var(--font-display)" }}>
            {taskTitle}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Status Section */}
          <div className="space-y-2">
            <Label htmlFor="status" className="text-base font-medium">
              Status
            </Label>
            <Select value={status} onValueChange={(value) => setStatus(value as TaskStatus)}>
              <SelectTrigger id="status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="not-started">Not Started</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="blocked">Blocked</SelectItem>
                <SelectItem value="in-review">In Review</SelectItem>
                <SelectItem value="done">Done</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Duration and Due Date Row */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="duration" className="text-base font-medium">
                Estimated Duration
              </Label>
              <Select 
                value={estimatedDuration.toString()} 
                onValueChange={(value) => setEstimatedDuration(parseInt(value))}
              >
                <SelectTrigger id="duration">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">15 minutes</SelectItem>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="60">1 hour</SelectItem>
                  <SelectItem value="90">1.5 hours</SelectItem>
                  <SelectItem value="120">2 hours</SelectItem>
                  <SelectItem value="180">3 hours</SelectItem>
                  <SelectItem value="240">4 hours</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dueDate" className="text-base font-medium">
                Due Date
              </Label>
              <Input
                id="dueDate"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </div>
          </div>

          {/* Priority Checkboxes */}
          <div className="flex gap-6">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="urgent"
                checked={urgent}
                onChange={(e) => setUrgent(e.target.checked)}
                className="w-4 h-4 rounded border-gray-300"
              />
              <Label htmlFor="urgent" className="text-base font-medium cursor-pointer">
                Urgent
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="important"
                checked={important}
                onChange={(e) => setImportant(e.target.checked)}
                className="w-4 h-4 rounded border-gray-300"
              />
              <Label htmlFor="important" className="text-base font-medium cursor-pointer">
                Important
              </Label>
            </div>
          </div>

          {/* Notes Section */}
          <div className="space-y-2">
            <Label htmlFor="notes" className="text-base font-medium">
              Notes
            </Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add detailed notes, thoughts, or context for this task..."
              className="min-h-[200px] resize-y"
              style={{ fontFamily: "var(--font-body)" }}
            />
          </div>

          {/* Links Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-base font-medium flex items-center gap-2">
                <LinkIcon className="w-4 h-4" />
                Links
              </Label>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowLinkForm(!showLinkForm)}
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Link
              </Button>
            </div>

            {showLinkForm && (
              <div className="p-4 border rounded-lg space-y-3 bg-muted/30">
                <div className="space-y-2">
                  <Label htmlFor="link-url">URL</Label>
                  <Input
                    id="link-url"
                    value={newLinkUrl}
                    onChange={(e) => setNewLinkUrl(e.target.value)}
                    placeholder="https://example.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="link-title">Title (optional)</Label>
                  <Input
                    id="link-title"
                    value={newLinkTitle}
                    onChange={(e) => setNewLinkTitle(e.target.value)}
                    placeholder="Link description"
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={addLink} size="sm">
                    Add
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowLinkForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            {links.length > 0 && (
              <div className="space-y-2">
                {links.map((link) => (
                  <div
                    key={link.id}
                    className="flex items-center justify-between p-3 border rounded-lg bg-card hover:bg-accent/10 transition-colors"
                  >
                    <a
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 text-sm text-primary hover:underline truncate"
                    >
                      {link.title}
                    </a>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeLink(link.id)}
                      className="ml-2"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Attachments Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-base font-medium flex items-center gap-2">
                <Paperclip className="w-4 h-4" />
                Attachments
              </Label>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAttachmentForm(!showAttachmentForm)}
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Attachment
              </Button>
            </div>

            {showAttachmentForm && (
              <div className="p-4 border rounded-lg space-y-3 bg-muted/30">
                <div className="space-y-2">
                  <Label htmlFor="attachment-url">File URL</Label>
                  <Input
                    id="attachment-url"
                    value={newAttachmentUrl}
                    onChange={(e) => setNewAttachmentUrl(e.target.value)}
                    placeholder="https://example.com/file.pdf"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="attachment-name">Name (optional)</Label>
                  <Input
                    id="attachment-name"
                    value={newAttachmentName}
                    onChange={(e) => setNewAttachmentName(e.target.value)}
                    placeholder="Document name"
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={addAttachment} size="sm">
                    Add
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowAttachmentForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            {attachments.length > 0 && (
              <div className="space-y-2">
                {attachments.map((attachment) => (
                  <div
                    key={attachment.id}
                    className="flex items-center justify-between p-3 border rounded-lg bg-card hover:bg-accent/10 transition-colors"
                  >
                    <a
                      href={attachment.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 text-sm text-primary hover:underline truncate"
                    >
                      {attachment.name}
                    </a>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeAttachment(attachment.id)}
                      className="ml-2"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex justify-between items-center pt-4 border-t">
          {onDelete && (
            <Button 
              variant="destructive" 
              onClick={() => {
                onDelete();
                onClose();
              }}
            >
              Delete Task
            </Button>
          )}
          <div className="flex gap-3 ml-auto">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleSave}>Save Changes</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
