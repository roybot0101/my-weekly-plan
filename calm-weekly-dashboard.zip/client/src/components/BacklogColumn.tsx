import { useState } from "react";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { TaskCard } from "@/components/TaskCard";
import { DroppableZone } from "@/components/DroppableZone";
import { TaskDetails } from "@/components/TaskDetailModal";

interface Task {
  id: string;
  text: string;
  completed: boolean;
  details: TaskDetails;
  weekKey?: string;
}

interface BacklogColumnProps {
  tasks: Task[];
  onToggleTask: (taskId: string) => void;
  onEditTask: (taskId: string, text: string) => void;
  onOpenDetails: (taskId: string) => void;
  onAddTask: (text: string) => void;
  editingTaskId: string | null;
  editText: string;
  onEditChange: (text: string) => void;
  onEditSave: () => void;
  onEditCancel: () => void;
}

export function BacklogColumn({
  tasks,
  onToggleTask,
  onEditTask,
  onOpenDetails,
  onAddTask,
  editingTaskId,
  editText,
  onEditChange,
  onEditSave,
  onEditCancel,
}: BacklogColumnProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [newTaskText, setNewTaskText] = useState("");

  const handleAddTask = () => {
    if (newTaskText.trim()) {
      onAddTask(newTaskText);
      setNewTaskText("");
      setIsAdding(false);
    }
  };

  return (
    <div className="flex-shrink-0 space-y-4 border-r pr-6" style={{ width: "280px" }}>
      <h3
        className="text-2xl font-semibold text-charcoal sticky top-0 bg-background/95 backdrop-blur-sm py-3"
        style={{ fontFamily: "var(--font-display)" }}
      >
        Backlog
      </h3>

      <DroppableZone id="backlog">
        <SortableContext items={tasks.map((t) => t.id)} strategy={verticalListSortingStrategy}>
          <div className="space-y-2 min-h-[100px]">
            {tasks.map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                onToggle={() => onToggleTask(task.id)}
                onEdit={() => onEditTask(task.id, task.text)}
                onOpenDetails={() => onOpenDetails(task.id)}
                isEditing={editingTaskId === task.id}
                editText={editText}
                onEditChange={onEditChange}
                onEditSave={onEditSave}
                onEditCancel={onEditCancel}
              />
            ))}

            {isAdding ? (
              <div className="flex gap-2">
                <Input
                  value={newTaskText}
                  onChange={(e) => setNewTaskText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleAddTask();
                    if (e.key === "Escape") setIsAdding(false);
                  }}
                  placeholder="Task title..."
                  autoFocus
                  className="flex-1"
                />
                <Button size="sm" onClick={handleAddTask}>
                  Add
                </Button>
              </div>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsAdding(true)}
                className="w-full border-dashed"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Task
              </Button>
            )}
          </div>
        </SortableContext>
      </DroppableZone>
    </div>
  );
}
