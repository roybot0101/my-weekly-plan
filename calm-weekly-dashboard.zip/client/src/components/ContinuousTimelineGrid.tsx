import { useDroppable } from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { TimelineTaskCard } from "./TimelineTaskCard";
import { Task } from "@/types/task";
import { getTimeMarkers, timeToYPosition } from "@/utils/timelineConfig";

interface ContinuousTimelineGridProps {
  dayIndex: number;
  dayName: string;
  date: string;
  tasks: Task[];
  onToggle: (taskId: string) => void;
  onEdit: (taskId: string, text: string) => void;
  onOpenDetails: (taskId: string) => void;
  editingTaskId: string | null;
  editText: string;
  onEditChange: (text: string) => void;
  onEditSave: () => void;
  onEditCancel: () => void;
}

export default function ContinuousTimelineGrid({
  dayIndex,
  dayName,
  date,
  tasks,
  onToggle,
  onEdit,
  onOpenDetails,
  editingTaskId,
  editText,
  onEditChange,
  onEditSave,
  onEditCancel,
}: ContinuousTimelineGridProps) {
  const timeMarkers = getTimeMarkers();
  
  // Create droppable zone for the entire day
  const { setNodeRef, isOver } = useDroppable({
    id: `day-${dayIndex}`,
  });

  // Sort tasks by startTime
  const sortedTasks = [...tasks].sort((a, b) => {
    const aTime = a.startTime ?? 0;
    const bTime = b.startTime ?? 0;
    return aTime - bTime;
  });

  return (
    <div className="flex flex-col h-full">
      {/* Day header */}
      <div className="sticky top-0 z-20 bg-background/95 backdrop-blur-sm border-b border-border px-4 py-3">
        <div className="text-sm font-medium text-foreground">{dayName}</div>
        <div className="text-xs text-muted-foreground">{date}</div>
      </div>

      {/* Timeline container */}
      <div
        ref={setNodeRef}
        className={`relative flex-1 min-h-[800px] transition-colors ${
          isOver ? "bg-primary/5" : ""
        }`}
      >
        {/* Time markers */}
        <div className="absolute inset-0 pointer-events-none">
          {timeMarkers.map((marker) => {
            const yPos = timeToYPosition(marker.minutes);
            return (
              <div
                key={marker.minutes}
                className="absolute left-0 right-0 border-t border-border/30"
                style={{ top: `${yPos}%` }}
              >
                <span className="absolute left-2 -top-2.5 text-xs text-muted-foreground bg-background px-1">
                  {marker.label}
                </span>
              </div>
            );
          })}
        </div>

        {/* Tasks */}
        <SortableContext items={sortedTasks.map((t) => t.id)} strategy={verticalListSortingStrategy}>
          <div className="relative h-full px-4">
            {sortedTasks.map((task) => {
              const yPos = timeToYPosition(task.startTime ?? 300);
              const duration = task.estimatedDuration ?? 60;
              const height = (duration / (24 * 60)) * 100; // Convert duration to % of full day
              
              return (
                <div
                  key={task.id}
                  className="absolute left-4 right-4"
                  style={{
                    top: `${yPos}%`,
                    minHeight: `${Math.max(height, 3)}%`, // Minimum 3% height
                  }}
                >
                  <TimelineTaskCard
                    task={task}
                    onToggle={() => onToggle(task.id)}
                    onEdit={() => onEdit(task.id, task.text)}
                    onOpenDetails={() => onOpenDetails(task.id)}
                    isEditing={editingTaskId === task.id}
                    editText={editText}
                    onEditChange={onEditChange}
                    onEditSave={onEditSave}
                    onEditCancel={onEditCancel}
                  />
                </div>
              );
            })}
          </div>
        </SortableContext>

        {/* Click to add task hint */}
        {tasks.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <p className="text-sm text-muted-foreground">Drop tasks here</p>
          </div>
        )}
      </div>
    </div>
  );
}
