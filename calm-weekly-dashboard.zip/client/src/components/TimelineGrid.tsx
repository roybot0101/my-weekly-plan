import { useMemo, useRef, useState, useEffect } from "react";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { useDroppable } from "@dnd-kit/core";
import { Task } from "@/types/task";
import { TimelineTaskCard } from "@/components/TimelineTaskCard";
import {
  TIME_SLOT_RANGES,
  TimeSlotKey,
  getTimeMarkers,
  timeToPixel,
  resolveCollisions,
  getCardHeight,
} from "@/utils/timePositioning";

interface TimelineGridProps {
  dayLabel: string;
  dayDate: string;
  tasks: Task[];
  timeSlotKey: TimeSlotKey;
  onToggleTask: (taskId: string) => void;
  onEditTask: (taskId: string, text: string) => void;
  onOpenDetails: (taskId: string) => void;
  onAddTask: () => void;
  editingTaskId: string | null;
  editText: string;
  onEditChange: (text: string) => void;
  onEditSave: () => void;
  onEditCancel: () => void;
  isToday?: boolean;
  dayIndex: number;
  timeSlotIndex: number;
}

export function TimelineGrid({
  dayLabel,
  dayDate,
  tasks,
  timeSlotKey,
  onToggleTask,
  onEditTask,
  onOpenDetails,
  onAddTask,
  editingTaskId,
  editText,
  onEditChange,
  onEditSave,
  onEditCancel,
  isToday = false,
  dayIndex,
  timeSlotIndex,
}: TimelineGridProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const droppableId = `${dayIndex}-${timeSlotIndex}`;
  const { setNodeRef, isOver } = useDroppable({ id: droppableId });
  
  // 100px per 30-minute block = 200px per hour
  // For 19 hours (5am-12am), total height is 3800px
  const PIXELS_PER_30_MIN = 100;
  const SLOT_HEIGHT = 3800; // 19 hours * 200px per hour
  
  // Track mouse position for drop zone highlighting
  const [hoverBlockIndex, setHoverBlockIndex] = useState<number | null>(null);
  
  // Get time markers for this slot
  const timeMarkers = useMemo(() => getTimeMarkers(timeSlotKey), [timeSlotKey]);
  
  // Use tasks as-is without collision resolution - let them go where user drops them
  const positionedTasks = tasks;

  return (
    <div className="relative">
      {/* Time slot container */}
      <div
        ref={(node) => {
          setNodeRef(node);
          if (containerRef.current !== node) {
            (containerRef as any).current = node;
          }
        }}
        data-droppable-id={droppableId}
        className={`relative border-b border-border/30 transition-colors`}
        style={{ height: `${SLOT_HEIGHT}px` }}
        onMouseMove={(e) => {
          if (isOver && containerRef.current) {
            const rect = containerRef.current.getBoundingClientRect();
            const y = e.clientY - rect.top;
            const blockIndex = Math.floor(y / PIXELS_PER_30_MIN);
            setHoverBlockIndex(blockIndex);
          }
        }}
        onMouseLeave={() => setHoverBlockIndex(null)}
      >
        {/* 30-minute block highlights */}
        {isOver && hoverBlockIndex !== null && (
          <div
            className="absolute left-0 right-0 bg-primary/20 border-2 border-primary/40 rounded-lg pointer-events-none z-10 transition-all"
            style={{
              top: `${hoverBlockIndex * PIXELS_PER_30_MIN}px`,
              height: `${PIXELS_PER_30_MIN}px`,
            }}
          />
        )}
        
        {/* Time markers */}
        {timeMarkers.map((marker, index) => {
          const isHourMark = marker.time % 60 === 0;
          const y = marker.position * SLOT_HEIGHT;
          
          return (
            <div
              key={marker.time}
              className="absolute left-0 right-0 flex items-center"
              style={{ top: `${y}px` }}
            >
              {/* Time label */}
              <span className={`
                text-xs px-2 py-0.5 rounded z-20 relative
                ${isHourMark 
                  ? 'text-muted-foreground font-medium bg-background' 
                  : 'text-muted-foreground/60'
                }
              `}>
                {marker.label}
              </span>
              
              {/* Grid line */}
              <div className={`
                flex-1 
                ${isHourMark ? 'border-t-2 border-border/40' : 'border-t border-border/20'}
              `} />
            </div>
          );
        })}
        
        {/* Tasks */}
        <SortableContext items={positionedTasks.map(t => t.id)} strategy={verticalListSortingStrategy}>
          {positionedTasks.map((task) => {
            const startTime = task.startTime ?? 0;
            const y = timeToPixel(startTime, SLOT_HEIGHT, timeSlotKey);
            const height = getCardHeight(task.estimatedDuration, SLOT_HEIGHT, timeSlotKey);
            
            return (
              <TimelineTaskCard
                key={task.id}
                task={task}
                onToggle={() => onToggleTask(task.id)}
                onEdit={() => onEditTask(task.id, task.text)}
                onOpenDetails={() => onOpenDetails(task.id)}
                isEditing={editingTaskId === task.id}
                editText={editText}
                onEditChange={onEditChange}
                onEditSave={onEditSave}
                onEditCancel={onEditCancel}
                style={{
                  top: `${y}px`,
                  height: `${height}px`,
                }}
              />
            );
          })}
        </SortableContext>
        
        {/* Click to add task overlay */}
        {tasks.length === 0 && (
          <button
            onClick={onAddTask}
            className="absolute inset-0 flex items-center justify-center text-muted-foreground/40 hover:text-muted-foreground/60 hover:bg-accent/5 transition-colors group"
          >
            <span className="text-sm">Click to add task</span>
          </button>
        )}
      </div>
    </div>
  );
}
