import ContinuousTimelineGrid from "@/components/ContinuousTimelineGrid";
import { Task } from "@/types/task";

interface WeeklyViewProps {
  days: Array<{
    day: string;
    date: string;
    tasks: Task[];
  }>;
  onToggleTask: (taskId: string) => void;
  onEditTask: (taskId: string, text: string) => void;
  onOpenDetails: (taskId: string) => void;
  editingTaskId: string | null;
  editText: string;
  onEditChange: (text: string) => void;
  onEditSave: () => void;
  onEditCancel: () => void;
}

export function WeeklyView({
  days,
  onToggleTask,
  onEditTask,
  onOpenDetails,
  editingTaskId,
  editText,
  onEditChange,
  onEditSave,
  onEditCancel,
}: WeeklyViewProps) {
  return (
    <div className="flex-1 overflow-auto">
      <div className="flex min-w-[1200px] h-full">
        {days.map((dayData, dayIndex) => (
          <div key={dayData.day} className="flex-1 border-r border-border last:border-r-0">
            <ContinuousTimelineGrid
              dayIndex={dayIndex}
              dayName={dayData.day}
              date={dayData.date}
              tasks={dayData.tasks}
              onToggle={onToggleTask}
              onEdit={onEditTask}
              onOpenDetails={onOpenDetails}
              editingTaskId={editingTaskId}
              editText={editText}
              onEditChange={onEditChange}
              onEditSave={onEditSave}
              onEditCancel={onEditCancel}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
