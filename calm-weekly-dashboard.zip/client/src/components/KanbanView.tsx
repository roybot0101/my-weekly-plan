/* Scandinavian Hygge with Soft Modernism
   Organizes tasks by status in columns, includes backlog */

import { Check, MoreVertical, Edit2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { TaskStatus } from "./TaskDetailModal";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { useDroppable } from "@dnd-kit/core";

interface Task {
  id: string;
  text: string;
  completed: boolean;
  details: {
    notes: string;
    links: Array<{ id: string; url: string; title: string }>;
    attachments: Array<{ id: string; name: string; url: string }>;
    status: TaskStatus;
  };
}

interface KanbanViewProps {
  tasks: Task[];
  backlogTasks: Task[];
  onToggleTask: (taskId: string) => void;
  onEditTask: (taskId: string, text: string) => void;
  onDeleteTask: (taskId: string) => void;
  onOpenDetails: (taskId: string) => void;
  editingTaskId: string | null;
  editText: string;
  onEditChange: (text: string) => void;
  onEditSave: () => void;
  onEditCancel: () => void;
}

const statusColumns: { status: TaskStatus | "backlog"; label: string }[] = [
  { status: "backlog", label: "Backlog" },
  { status: "not-started", label: "Not Started" },
  { status: "in-progress", label: "In Progress" },
  { status: "blocked", label: "Blocked" },
  { status: "in-review", label: "In Review" },
  { status: "done", label: "Done" },
];

function getStatusColor(status: TaskStatus): string {
  switch (status) {
    case "not-started":
      return "bg-card";
    case "in-progress":
      return "bg-green-50 border-green-200";
    case "blocked":
      return "bg-red-50 border-red-200";
    case "in-review":
      return "bg-blue-50 border-blue-200";
    case "done":
      return "bg-accent/20 opacity-60";
    default:
      return "bg-card";
  }
}

function DroppableZone({ id, children }: { id: string; children: React.ReactNode }) {
  const { setNodeRef, isOver } = useDroppable({ id });
  return (
    <div 
      ref={setNodeRef} 
      className={`min-h-[400px] flex-1 p-2 rounded-lg transition-colors ${
        isOver ? 'bg-primary/10 ring-2 ring-primary' : ''
      }`}
    >
      {children}
    </div>
  );
}

function KanbanTask({
  task,
  onToggle,
  onEdit,
  onDelete,
  onOpenDetails,
  isEditing,
  editText,
  onEditChange,
  onEditSave,
  onEditCancel,
}: {
  task: Task;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onOpenDetails: () => void;
  isEditing: boolean;
  editText: string;
  onEditChange: (text: string) => void;
  onEditSave: () => void;
  onEditCancel: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: task.id,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      onClick={(e) => {
        // Only trigger detail view if clicking on the card background/perimeter
        if (e.target === e.currentTarget) {
          onOpenDetails();
        }
      }}
      className={`
        w-full flex items-start gap-2 px-4 py-3 rounded-[24px] 
        transition-all duration-500 ease-in-out
        ${getStatusColor(task.details.status)}
        shadow-sm border border-border/50
        group cursor-pointer hover:shadow-lg
        relative
        ${task.completed ? 'animate-fade-in' : ''}
      `}
    >
      {/* Drag handle area - invisible overlay on left/right edges */}
      <div {...listeners} className="absolute inset-y-0 left-0 w-12 cursor-move z-10" />
      <div {...listeners} className="absolute inset-y-0 right-0 w-12 cursor-move z-10" />
      <button
        onClick={(e) => {
          e.stopPropagation();
          onToggle();
        }}
        className={`
          mt-0.5 w-5 h-5 rounded-full border-2 flex-shrink-0
          flex items-center justify-center
          transition-all duration-400 ease-in-out
          relative z-20
          ${
            task.completed
              ? "bg-primary border-primary scale-100"
              : "border-muted-foreground/40 group-hover:border-primary/60 group-hover:scale-110"
          }
        `}
      >
        {task.completed && <Check className="w-3 h-3 text-primary-foreground" />}
      </button>

      <div className="flex-1 relative z-20">
        {isEditing ? (
          <input
            type="text"
            value={editText}
            onChange={(e) => onEditChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") onEditSave();
              if (e.key === "Escape") onEditCancel();
              e.stopPropagation();
            }}
            onBlur={onEditSave}
            onClick={(e) => e.stopPropagation()}
            className="w-full px-2 py-1 text-sm border rounded focus:outline-none focus:ring-2 focus:ring-primary"
            autoFocus
          />
        ) : (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit();
            }}
            className="w-full text-left cursor-text"
          >
            <span
              className={`
                text-sm leading-relaxed
                ${task.completed ? "line-through text-muted-foreground" : "text-card-foreground"}
              `}
              style={{ fontFamily: "var(--font-body)" }}
            >
              {task.text}
            </span>
          </button>
        )}
        {!isEditing && (task.details.notes ||
          task.details.links.length > 0 ||
          task.details.attachments.length > 0) && (
          <div className="flex gap-1 mt-1">
            {task.details.notes && <span className="text-xs text-muted-foreground">📝</span>}
            {task.details.links.length > 0 && (
              <span className="text-xs text-muted-foreground">
                🔗 {task.details.links.length}
              </span>
            )}
            {task.details.attachments.length > 0 && (
              <span className="text-xs text-muted-foreground">
                📎 {task.details.attachments.length}
              </span>
            )}
          </div>
        )}
      </div>


    </div>
  );
}

export default function KanbanView({
  tasks,
  backlogTasks,
  onToggleTask,
  onEditTask,
  onDeleteTask,
  onOpenDetails,
  editingTaskId,
  editText,
  onEditChange,
  onEditSave,
  onEditCancel,
}: KanbanViewProps) {
  const getTasksByStatus = (status: TaskStatus | "backlog") => {
    if (status === "backlog") {
      return backlogTasks;
    }
    return tasks.filter((task) => task.details.status === status);
  };

  return (
    <div className="grid grid-cols-6 gap-6">
      {statusColumns.map((column) => {
        const columnTasks = getTasksByStatus(column.status);
        return (
          <div key={column.status} className="flex flex-col space-y-4">
            <div className="sticky top-0 bg-background/95 backdrop-blur-sm py-3 z-10">
              <h3
                className="text-lg font-semibold text-charcoal"
                style={{ fontFamily: "var(--font-display)" }}
              >
                {column.label}
              </h3>
              <p className="text-sm text-muted-foreground">{columnTasks.length} tasks</p>
            </div>

            <DroppableZone id={`kanban-${column.status}`}>
              <SortableContext items={columnTasks.map((t) => t.id)} strategy={verticalListSortingStrategy}>
                <div className="space-y-2">
                  {columnTasks.map((task) => (
                    <KanbanTask
                      key={task.id}
                      task={task}
                      onToggle={() => onToggleTask(task.id)}
                      onEdit={() => onEditTask(task.id, task.text)}
                      onDelete={() => onDeleteTask(task.id)}
                      onOpenDetails={() => onOpenDetails(task.id)}
                      isEditing={editingTaskId === task.id}
                      editText={editText}
                      onEditChange={onEditChange}
                      onEditSave={onEditSave}
                      onEditCancel={onEditCancel}
                    />
                  ))}
                </div>
              </SortableContext>
            </DroppableZone>
          </div>
        );
      })}
    </div>
  );
}
