/**
 * Timeline configuration for the weekly planner
 * Defines work hours and time markers
 */

export const TIMELINE_CONFIG = {
  // Start and end times in minutes from midnight
  START_TIME: 300, // 5am = 5 * 60
  END_TIME: 1440, // 12am (midnight) = 24 * 60
  
  // Interval for time markers (in minutes)
  MARKER_INTERVAL: 60, // Show markers every hour
  
  // Snap interval for drag-and-drop (in minutes)
  SNAP_INTERVAL: 30, // Snap to 30-minute intervals
  
  // Default task duration (in minutes)
  DEFAULT_DURATION: 60,
  
  // Minimum task duration (in minutes)
  MIN_DURATION: 30,
};

/**
 * Get total timeline duration in minutes
 */
export function getTimelineDuration(): number {
  return TIMELINE_CONFIG.END_TIME - TIMELINE_CONFIG.START_TIME;
}

/**
 * Convert minutes from midnight to display time (e.g., 300 → "5:00am")
 */
export function minutesToTimeString(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  const period = hours >= 12 ? 'pm' : 'am';
  const displayHours = hours === 0 ? 12 : hours > 12 ? hours - 12 : hours;
  
  if (mins === 0) {
    return `${displayHours}${period}`;
  }
  return `${displayHours}:${mins.toString().padStart(2, '0')}${period}`;
}

/**
 * Get all time markers for the timeline
 * Returns array of {minutes, label} objects
 */
export function getTimeMarkers(): Array<{ minutes: number; label: string }> {
  const markers: Array<{ minutes: number; label: string }> = [];
  
  for (
    let time = TIMELINE_CONFIG.START_TIME;
    time <= TIMELINE_CONFIG.END_TIME;
    time += TIMELINE_CONFIG.MARKER_INTERVAL
  ) {
    markers.push({
      minutes: time,
      label: minutesToTimeString(time),
    });
  }
  
  return markers;
}

/**
 * Snap time to nearest interval
 */
export function snapToInterval(minutes: number): number {
  const interval = TIMELINE_CONFIG.SNAP_INTERVAL;
  return Math.round(minutes / interval) * interval;
}

/**
 * Calculate Y position (%) for a given time
 */
export function timeToYPosition(minutes: number): number {
  const duration = getTimelineDuration();
  const offset = minutes - TIMELINE_CONFIG.START_TIME;
  return (offset / duration) * 100;
}

/**
 * Calculate time from Y position (%)
 */
export function yPositionToTime(yPercent: number): number {
  const duration = getTimelineDuration();
  const minutes = TIMELINE_CONFIG.START_TIME + (yPercent / 100) * duration;
  return snapToInterval(Math.max(TIMELINE_CONFIG.START_TIME, Math.min(TIMELINE_CONFIG.END_TIME, minutes)));
}
