/**
 * Utility functions for validating task placement in time slots
 */

interface Task {
  id: string;
  startTime?: number; // in minutes from midnight
  estimatedDuration?: number; // in minutes
}

/**
 * Calculate available time in a specific time slot
 * @param startMinutes - Start time in minutes from midnight (e.g., 540 for 9am)
 * @param endMinutes - End time in minutes from midnight (e.g., 660 for 11am)
 * @param existingTasks - Tasks already in this time slot
 * @returns Available time in minutes
 */
export function calculateAvailableTime(
  startMinutes: number,
  endMinutes: number,
  existingTasks: Task[]
): number {
  const totalSlotDuration = endMinutes - startMinutes;
  
  // Calculate total used time
  const usedTime = existingTasks.reduce((total, task) => {
    return total + (task.estimatedDuration || 0);
  }, 0);
  
  return Math.max(0, totalSlotDuration - usedTime);
}

/**
 * Check if a task can fit in a specific time slot
 * @param taskDuration - Duration of the task to place (in minutes)
 * @param startMinutes - Start time of the slot
 * @param endMinutes - End time of the slot
 * @param existingTasks - Tasks already in this slot
 * @returns true if task fits, false otherwise
 */
export function canTaskFitInSlot(
  taskDuration: number,
  startMinutes: number,
  endMinutes: number,
  existingTasks: Task[]
): boolean {
  const availableTime = calculateAvailableTime(startMinutes, endMinutes, existingTasks);
  return taskDuration <= availableTime;
}

/**
 * Get time slot boundaries for a given time
 * Time slots are 30-minute intervals
 * @param minutes - Time in minutes from midnight
 * @returns Object with start and end times
 */
export function getTimeSlotBoundaries(minutes: number): { start: number; end: number } {
  // Round down to nearest 30-minute interval
  const start = Math.floor(minutes / 30) * 30;
  const end = start + 30;
  return { start, end };
}

/**
 * Convert time in minutes to human-readable format
 * @param minutes - Time in minutes from midnight
 * @returns Formatted time string (e.g., "9:00am")
 */
export function formatTimeFromMinutes(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  const period = hours >= 12 ? 'pm' : 'am';
  const displayHours = hours > 12 ? hours - 12 : hours === 0 ? 12 : hours;
  return mins === 0 
    ? `${displayHours}${period}`
    : `${displayHours}:${mins.toString().padStart(2, '0')}${period}`;
}

/**
 * Get all tasks in a specific day and time range
 * @param allTasks - All tasks for the week
 * @param dayIndex - Day index (0-4 for Mon-Fri)
 * @param startMinutes - Start of time range
 * @param endMinutes - End of time range
 * @returns Tasks in that time range
 */
export function getTasksInTimeRange(
  allTasks: Task[],
  dayIndex: number,
  startMinutes: number,
  endMinutes: number
): Task[] {
  return allTasks.filter(task => {
    if (!task.startTime) return false;
    
    const taskEnd = task.startTime + (task.estimatedDuration || 0);
    
    // Check if task overlaps with the time range
    return task.startTime < endMinutes && taskEnd > startMinutes;
  });
}
