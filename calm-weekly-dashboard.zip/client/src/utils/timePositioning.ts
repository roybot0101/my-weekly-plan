/**
 * Time-based positioning utilities for task cards
 * Handles hour/half-hour snapping and collision prevention
 */

import { Task } from "@/types/task";

// Time slot definitions (in minutes from midnight)
export const TIME_SLOT_RANGES = {
  "5am - 12am": { start: 5 * 60, end: 24 * 60, duration: 1140 }, // 19 hours: 5am to midnight
};

export type TimeSlotKey = keyof typeof TIME_SLOT_RANGES;

/**
 * Convert pixel position to time (minutes from slot start)
 * @param pixelY - Y position in pixels within the time slot
 * @param slotHeight - Total height of the time slot in pixels
 * @param slotKey - Time slot identifier
 * @returns Minutes from slot start, snapped to 30-minute intervals
 */
export function pixelToTime(
  pixelY: number,
  slotHeight: number,
  slotKey: TimeSlotKey
): number {
  const slotInfo = TIME_SLOT_RANGES[slotKey];
  const ratio = Math.max(0, Math.min(1, pixelY / slotHeight));
  const minutesFromSlotStart = ratio * slotInfo.duration;
  
  // Snap to 30-minute intervals
  return Math.round(minutesFromSlotStart / 30) * 30;
}

/**
 * Convert time to pixel position
 * @param minutesFromSlotStart - Minutes from the start of the time slot
 * @param slotHeight - Total height of the time slot in pixels
 * @param slotKey - Time slot identifier
 * @returns Y position in pixels
 */
export function timeToPixel(
  minutesFromSlotStart: number,
  slotHeight: number,
  slotKey: TimeSlotKey
): number {
  const slotInfo = TIME_SLOT_RANGES[slotKey];
  const ratio = minutesFromSlotStart / slotInfo.duration;
  return ratio * slotHeight;
}

/**
 * Get absolute time in minutes from midnight
 * @param slotKey - Time slot identifier
 * @param minutesFromSlotStart - Minutes from slot start
 * @returns Minutes from midnight
 */
export function getAbsoluteTime(
  slotKey: TimeSlotKey,
  minutesFromSlotStart: number
): number {
  const slotInfo = TIME_SLOT_RANGES[slotKey];
  return slotInfo.start + minutesFromSlotStart;
}

/**
 * Format time for display
 * @param minutesFromMidnight - Minutes from midnight
 * @returns Formatted time string (e.g., "9:30am")
 */
export function formatTime(minutesFromMidnight: number): string {
  const hours = Math.floor(minutesFromMidnight / 60);
  const minutes = minutesFromMidnight % 60;
  const period = hours >= 12 ? "pm" : "am";
  const displayHours = hours > 12 ? hours - 12 : hours === 0 ? 12 : hours;
  
  if (minutes === 0) {
    return `${displayHours}${period}`;
  }
  return `${displayHours}:${minutes.toString().padStart(2, "0")}${period}`;
}

/**
 * Calculate card height based on estimated duration
 * @param estimatedDuration - Duration in minutes
 * @param slotHeight - Total height of the time slot in pixels
 * @param slotKey - Time slot identifier
 * @returns Height in pixels
 */
export function getCardHeight(
  estimatedDuration: number | undefined,
  slotHeight: number,
  slotKey: TimeSlotKey
): number {
  if (!estimatedDuration) return 60; // Default height
  
  const slotInfo = TIME_SLOT_RANGES[slotKey];
  const ratio = estimatedDuration / slotInfo.duration;
  return Math.max(40, Math.min(slotHeight * ratio, slotHeight - 10));
}

/**
 * Detect and resolve collisions between tasks
 * @param tasks - Array of tasks in the time slot
 * @param slotKey - Time slot identifier
 * @returns Tasks with adjusted startTime to prevent overlaps
 */
export function resolveCollisions(
  tasks: Task[],
  slotKey: TimeSlotKey
): Task[] {
  if (tasks.length === 0) return tasks;
  
  // Sort by startTime
  const sorted = [...tasks].sort((a, b) => {
    const aTime = a.startTime ?? 0;
    const bTime = b.startTime ?? 0;
    return aTime - bTime;
  });
  
  const slotInfo = TIME_SLOT_RANGES[slotKey];
  const adjusted: Task[] = [];
  let currentTime = 0;
  
  for (const task of sorted) {
    const requestedTime = task.startTime ?? 0;
    const duration = task.estimatedDuration ?? 30;
    
    // If requested time overlaps with previous task, push it down
    const actualTime = Math.max(requestedTime, currentTime);
    
    // Ensure task fits within slot
    const endTime = Math.min(actualTime + duration, slotInfo.duration);
    
    adjusted.push({
      ...task,
      startTime: actualTime,
    });
    
    currentTime = endTime;
  }
  
  return adjusted;
}

/**
 * Get time markers for visual grid
 * @param slotKey - Time slot identifier
 * @returns Array of { time: minutes from midnight, label: string, position: 0-1 }
 */
export function getTimeMarkers(slotKey: TimeSlotKey): Array<{
  time: number;
  label: string;
  position: number;
}> {
  const slotInfo = TIME_SLOT_RANGES[slotKey];
  const markers: Array<{ time: number; label: string; position: number }> = [];
  
  // Generate markers every 30 minutes
  for (let minutes = 0; minutes <= slotInfo.duration; minutes += 30) {
    const absoluteTime = slotInfo.start + minutes;
    markers.push({
      time: absoluteTime,
      label: formatTime(absoluteTime),
      position: minutes / slotInfo.duration,
    });
  }
  
  return markers;
}
