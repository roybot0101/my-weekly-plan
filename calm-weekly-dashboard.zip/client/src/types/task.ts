import { TaskDetails } from "@/components/TaskDetailModal";

export interface Task {
  id: string;
  text: string;
  completed: boolean;
  details: TaskDetails;
  weekKey?: string;
  estimatedDuration?: number;
  startTime?: number;
  dueDate?: number;
  urgent?: boolean;
  important?: boolean;
  projectId?: string;
}

export interface DayData {
  day: string;
  date: string;
  timeSlots: TimeSlot[];
}

export interface TimeSlot {
  time: string;
  tasks: Task[];
  isOpen: boolean;
}

export const TIME_SLOTS = ["5am - 12am"];

export const DAYS_OF_WEEK = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
