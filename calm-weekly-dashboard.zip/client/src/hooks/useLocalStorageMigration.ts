import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { TaskStatus } from "@/components/TaskDetailModal";

const TIME_SLOTS = ["5am - 7am", "9am - 11am", "1pm - 3pm", "9pm - 12am"];
const MIGRATION_KEY = "calm-week-migrated";

export function useLocalStorageMigration() {
  const [isMigrating, setIsMigrating] = useState(false);
  const [migrationComplete, setMigrationComplete] = useState(false);
  const createTask = trpc.tasks.create.useMutation();
  const utils = trpc.useUtils();

  useEffect(() => {
    const migrate = async () => {
      // Check if already migrated
      if (localStorage.getItem(MIGRATION_KEY)) {
        setMigrationComplete(true);
        return;
      }

      // Check for old localStorage data
      const stored = localStorage.getItem("calm-week-data");
      if (!stored) {
        // No data to migrate
        localStorage.setItem(MIGRATION_KEY, "true");
        setMigrationComplete(true);
        return;
      }

      try {
        setIsMigrating(true);
        const data = JSON.parse(stored);

        // Migrate backlog tasks
        if (data.backlog && Array.isArray(data.backlog)) {
          for (const task of data.backlog) {
            await createTask.mutateAsync({
              taskId: task.id || `migrated-${Date.now()}-${Math.random()}`,
              text: task.text,
              completed: task.completed || false,
              status: task.details?.status || "not-started",
              notes: task.details?.notes || "",
              links: task.details?.links || [],
              attachments: task.details?.attachments || [],
              // Backlog tasks have no week/day/timeSlot
            });
          }
        }

        // Migrate week tasks
        if (data.weeks) {
          for (const [weekKey, weekData] of Object.entries(data.weeks)) {
            if (!weekData || !(weekData as any).days) continue;

            const days = (weekData as any).days;
            days.forEach((day: any, dayIndex: number) => {
              day.timeSlots?.forEach((slot: any, timeIndex: number) => {
                slot.tasks?.forEach(async (task: any) => {
                  await createTask.mutateAsync({
                    taskId: task.id || `migrated-${Date.now()}-${Math.random()}`,
                    text: task.text,
                    completed: task.completed || false,
                    status: task.details?.status || "not-started",
                    notes: task.details?.notes || "",
                    links: task.details?.links || [],
                    attachments: task.details?.attachments || [],
                    weekKey,
                    dayIndex,
                    timeSlotIndex: timeIndex,
                  });
                });
              });
            });
          }
        }

        // Mark migration as complete
        localStorage.setItem(MIGRATION_KEY, "true");
        
        // Refresh tasks from database
        await utils.tasks.getAll.invalidate();
        
        setMigrationComplete(true);
        console.log("✅ Successfully migrated localStorage data to database");
      } catch (error) {
        console.error("Failed to migrate localStorage data:", error);
        // Don't mark as migrated so we can retry
      } finally {
        setIsMigrating(false);
      }
    };

    migrate();
  }, []);

  return { isMigrating, migrationComplete };
}
