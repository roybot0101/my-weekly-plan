# Calm Weekly Dashboard TODO

## Completed Features
- [x] Basic weekly dashboard layout
- [x] Scandinavian hygge design
- [x] Collapsible time blocks
- [x] Drag-and-drop functionality
- [x] Week navigation
- [x] Status system (Not Started, In Progress, Blocked, In Review, Done)
- [x] Kanban view
- [x] Global persistent backlog
- [x] Inline task editing
- [x] Task detail modal with rich text, links, attachments
- [x] Click-to-edit task titles
- [x] Delete button in task modal
- [x] Task completion animation
- [x] Weekly progress indicator
- [x] Current day highlighting
- [x] Visual drop zone feedback

## Hybrid Monetization Model
- [x] Upgrade project to web-db-user (database + auth)
- [x] Create database schema for tasks and subscriptions
- [x] Build backend API (tRPC) for task operations
- [ ] Migrate frontend from localStorage to tRPC/database
- [ ] Add Stripe integration for subscriptions
- [ ] Implement tier-based feature gating (Free/Ad-Free/Pro)
- [ ] Integrate Google AdSense for free tier
- [ ] Create pricing page
- [ ] Build upgrade flow UI
- [ ] Test payment and subscription flows

## Frontend Database Migration - Fresh Rebuild (Completed)
- [x] Create new Home.tsx with authentication wrapper and loading states
- [x] Build TaskCard component with drag-and-drop and smart click detection
- [x] Build TimeSlot component with collapsible sections
- [x] Build BacklogColumn component
- [x] Build WeeklyView component with week navigation
- [x] Build DroppableZone helper component
- [x] Create useTaskData hook for database operations
- [x] Add localStorage migration helper for existing users
- [x] Fix weekKey format mismatch (W7 vs W07)
- [x] Verify tasks load correctly from database
- [ ] Update KanbanView to use database data via useTaskData hook
- [ ] Test all drag-and-drop functionality (time slots, days, backlog, kanban)
- [ ] Test week navigation and data persistence
- [ ] Test all task operations (add, edit, delete, toggle, update details)

## Bug Fixes
- [x] Fix current day highlighting to use actual current date instead of hardcoded Feb 10, 2026

## Advanced Project Management Features (In Progress)

### Phase 1: New Task Fields
- [x] Add dueDate, urgent, important, estimatedDuration fields to tasks table schema
- [x] Update backend API to handle new fields
- [ ] Update task detail modal to show new fields

### Phase 2: Projects System
- [x] Create projects table in database
- [x] Add projectId foreign key to tasks table
- [x] Build backend API for project CRUD operations
- [ ] Create Projects tab view in UI
- [ ] Add project assignment in task detail modal
- [ ] Add "Create Project" option in task detail modal

### Phase 3: Backlog Enhancements
- [x] Add backend API for moving incomplete tasks to backlog
- [ ] Add "Move incomplete tasks to backlog" button UI for past weeks
- [ ] Add "Tasks from last week" section header in backlog
- [ ] Implement manual sort view (drag to reorder)
- [ ] Implement group by project view
- [ ] Implement AI-powered priority ranking view

### Phase 4: AI Prioritization
- [ ] Build LLM integration for task ranking
- [ ] Create backend endpoint for AI prioritization
- [ ] Add UI toggle for AI-ranked view in backlog

### Phase 5: Visual Time Blocking
- [ ] Replace collapsible time slots with continuous 30-min grid
- [ ] Show tasks as visual blocks spanning their duration
- [ ] Add drag-and-drop validation (check available time)
- [ ] Build UI for setting daily available hours
- [ ] Add option to apply hours to whole week or per day

## Visual Time-Blocking Calendar (In Progress)
- [x] Create TimelineGrid component with 30-minute sections
- [x] Replace collapsible TimeSlot components with timeline view
- [x] Update task rendering to show as visual blocks spanning duration
- [x] Add time labels on the left (5am, 5:30am, 6am, etc.)
- [ ] Implement drag-and-drop with time slot validation
- [ ] Add visual feedback for insufficient time when dragging
- [ ] Create settings UI for configurable daily hours
- [ ] Add option to apply hours to whole week or per day

## Drag-and-Drop Validation (In Progress)
- [x] Add duration field to TaskDetailModal UI
- [x] Add due date, urgent, and important fields to TaskDetailModal
- [x] Update TaskDetails interface with new fields
- [x] Implement time slot availability calculation utilities
- [ ] Integrate validation into drag-and-drop handlers
- [ ] Add visual feedback for valid/invalid drop zones during drag
- [ ] Prevent dropping tasks into insufficient time slots
- [ ] Show error message/toast when drop is invalid

## UI Fixes
- [x] Remove redundant left time column from WeeklyView
- [x] Add padding to top of timeline to prevent first time label (5am) from being cut off

## Task Card Interactivity Restoration
- [x] Add drag-and-drop functionality to timeline tasks
- [x] Add drag handle icon on right side of task cards (shows on hover)
- [x] Implement inline editing with text cursor on task title
- [x] Add click-to-view-details on card body with pointer cursor
- [x] Create TimelineTaskCard component with all interactive features
- [x] Add visual cursor changes (grab, text, pointer) for different card areas

## Bug Fixes - Task Card Interactions (Feb 16, 2026)
- [x] Change cursor to pointer (hand) when hovering over card areas that open detail modal
- [x] Make drag handle icon always visible (not just on hover)
- [x] Ensure backlog cards have exact same interaction pattern as timeline cards
- [x] Fix drag-and-drop persistence - tasks snap back to previous position after drag

## Cursor and Interaction Fixes (Feb 16, 2026 - Round 2)
- [x] Change cursor on empty timeline slots to default arrow (not pointer)
- [x] Make cursor pointer (👆) only on card body area that opens details (not the whole card)
- [x] Fix backlog cards so clicking them opens detail modal

## Cursor Hand Pointer Fix (Feb 16, 2026)
- [x] Debug why cursor-pointer class is showing arrow instead of hand on card body
- [x] Fix card body overlay to show hand pointer cursor when hovering

## Code Audit and Refactoring (Feb 16, 2026)
- [x] Debug why cursor overlay still not showing hand pointer in browser
- [x] Refactor card components to remove clunky interaction code
- [x] Optimize state management and data flow
- [x] Remove redundant code and prepare for future features (time validation, keyboard shortcuts, bulk operations)
- [x] Extract shared utilities to /utils/dateUtils.ts
- [x] Extract shared types to /types/task.ts
- [x] Remove duplicate helper functions from multiple files

## Time-Based Positioning System (Feb 16, 2026)
- [x] Design hour/half-hour grid system for time slots
- [ ] Implement time snapping when dragging cards (drag handlers need update)
- [x] Add collision detection and auto-positioning to prevent card layering
- [x] Add visual time markers (hour lines) in time slots
- [ ] Show time preview while dragging
- [x] Update database schema to store startTime for each task
- [x] Set default startTime for new and existing tasks

## Bug Fixes - Drag and Duration (Feb 16, 2026)
- [x] Fix drag-and-drop - cards snap back instead of moving to new slot
- [x] Fix duration changes not saving from task detail modal

## Drag Between Time Slots Fix (Feb 16, 2026)
- [x] Fix drag-and-drop to allow moving cards between different time slots on the same day (currently only works across days)

## Precise Time Positioning (Feb 16, 2026)
- [x] Add DragOver handler to capture mouse Y position during drag
- [x] Calculate target time from Y-coordinate and snap to nearest 30-minute interval
- [x] Update card startTime based on drop position
- [ ] Add visual preview showing target time while dragging (optional enhancement)

## Single Continuous Time Block (Feb 17, 2026)
- [x] Update TIME_SLOTS array to single entry: "5am - 12am"
- [x] Update time calculation to work with 19-hour (1140 minute) range
- [x] Ensure drag-and-drop positioning works correctly in continuous block

## Precise Time Positioning via Y-Coordinate (Feb 17, 2026)
- [x] Calculate drop time from mouse Y-coordinate position on timeline
- [x] Remove auto-stacking behavior (tasks should go where dropped, not next available slot)
- [x] Allow gaps in timeline (e.g., tasks at 5am and 9am with nothing 6-9am)

## Y-Coordinate Calculation Bug (Feb 17, 2026)
- [x] Fix: Tasks move half hour down from drop position instead of to exact drop location
- [x] Fix: Cannot move tasks back to original position after dragging
- [x] Debug coordinate capture to get actual drop Y position, not start position
- [x] Use active.rect.current.translated to get actual drop position instead of activatorEvent

## Timeline Height and Drop Zone Feedback (Feb 17, 2026)
- [ ] Increase timeline height: 100px per 30-minute block (200px per hour, 3800px total for 5am-12am)
- [ ] Add visual drop zone highlights for each 30-minute block during drag operations
